Partner Ledger Report with Partner Filter
=========================================

Creates a partner ledger report by filtering partners


Installation
============
	- www.odoo.com/documentation/14.0/setup/install.html
	- Install our custom addon

Configuration
=============

No additional configurations needed

Credits
=======
Faslu ca v11 @ cybrosys, Contact: odoo@cybrosys.com
Afras Habis v13 @ cybrosys, Contact: odoo@cybrosys.com
Jibin James v14 @ cybrosys, Contact: odoo@cybrosys.com
